﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INVOICE_supermarket
{
    internal class Class1
    {
    }
}
